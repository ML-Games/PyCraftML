from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController

app = Ursina()
grass = load_texture('grass_block.png')
stone = load_texture('stone_block.png')
brick = load_texture('brick_block.png')
dirt = load_texture('dirt_block.png')
skyy = load_texture('skybox.png')
armm = load_texture('arm_texture.png')
punch_sound = Audio('punch_sound', loop=False, autoplay=False)
block_pick = 1

window.fps_counter.enabled = False
window.exit_button.visible = False

def update():  # Check user inputs
    global block_pick
    if held_keys['left mouse'] or held_keys['right mouse']:
        hand.active()
    else:
        hand.passive()
    if held_keys['1']: block_pick = 1
    if held_keys['2']: block_pick = 2
    if held_keys['3']: block_pick = 3
    if held_keys['4']: block_pick = 4

class Voxel(Button):  # Block creation + deletion
    def __init__(self, position=(0, 0, 0), texture=grass):
        super().__init__(
            parent=scene,
            position=position,
            model='block',
            origin_y=0.5,
            texture=texture,
            color=color.color(0, 0, 1),
            scale=0.5)

    def input(self, key):
        if self.hovered:
            if key == 'left mouse down':
                punch_sound.play()
                if block_pick == 1: Voxel(position=self.position + mouse.normal, texture=grass)
                if block_pick == 2: Voxel(position=self.position + mouse.normal, texture=stone)
                if block_pick == 3: Voxel(position=self.position + mouse.normal, texture=brick)
                if block_pick == 4: Voxel(position=self.position + mouse.normal, texture=dirt)

            if key == 'right mouse down':
                punch_sound.play()
                destroy(self)

class Sky(Entity):  # Sky creation
    def __init__(self):
        super().__init__(
            parent=scene,
            model='sphere',
            texture=skyy,
            scale=150,
            double_sided=True)

class Hand(Entity):  # Hand creation and movements
    def __init__(self):
        super().__init__(
            parent=camera.ui,
            model='arm',
            texture=armm,
            scale=0.2,
            rotation=Vec3(150, -10, 0),
            position=Vec2(0.4, -0.6))

    def active(self):
        self.position = Vec2(0.3, -0.5)

    def passive(self):
        self.position = Vec2(0.4, -0.6)

for z in range(20):  # Load map
    for x in range(20):
        voxel = Voxel(position=(x, 0, z))

player = FirstPersonController()
sky = Sky()
hand = Hand()
app.run()
